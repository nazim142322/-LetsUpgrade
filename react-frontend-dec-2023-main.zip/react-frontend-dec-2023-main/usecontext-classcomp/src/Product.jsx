import Category from "./Category";

export default function Product()
{

    return (
        <div className="product">
            <h1>Product Comp</h1>
            <Category/>
        </div>
    )
}

// export default Product;