function Home()
{
    return (
        <h1>Welcome Everyone</h1>
    )
}

export default Home;