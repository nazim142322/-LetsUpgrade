function Service()
{
    return (
        <div className="service">

            <div className="serv">Service 1</div>
            <div className="serv">Service 2</div>
            <div className="serv">Service 3</div>
            <div className="serv">Service 4</div>

        </div>
    )
}

export default Service;