function Location()
{
    return (
        <h1>I am Location Component</h1>
    )
}

export default Location;