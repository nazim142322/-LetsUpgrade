function Prices()
{
    return (
        <h1>Prices Component</h1>
    )
}

export default Prices;