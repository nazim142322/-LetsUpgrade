function Image()
{
    return (
        <h1>Image Component</h1>
    )
}

export default Image;