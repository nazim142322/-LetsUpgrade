function Product()
{
    return (
        <div className="product">

            <div className="prod">Product 1</div>
            <div className="prod">Product 2</div>
            <div className="prod">Product 3</div>
            <div className="prod">Product 4</div>

        </div>
    )
}

export default Product;